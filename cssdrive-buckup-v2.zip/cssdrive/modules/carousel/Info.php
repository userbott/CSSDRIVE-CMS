<?php

    return [
        'name'          =>  $core->lang['carousel']['module_name'],
        'description'   =>  $core->lang['carousel']['module_desc'],
        'author'        =>  'Sruu.pl',
        'version'       =>  '1.0',
        'icon'          =>  'retweet',
    ];