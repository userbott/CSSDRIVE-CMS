<?php

    return [
        'name'          =>  $core->lang['langswitcher']['module_name'],
        'description'   =>  $core->lang['langswitcher']['module_desc'],
        'author'        =>  'Sruu.pl',
        'version'       =>  '1.0',
        'icon'          =>  'flag',
    ];