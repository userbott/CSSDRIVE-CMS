<?php
    
    return [
        'name'          =>  $core->lang['dashboard']['module_name'],
        'description'   =>  $core->lang['dashboard']['module_desc'],
        'author'        =>  'Sruu.pl',
        'version'       =>  '1.0',
        'icon'          =>  'home'
    ];

?>