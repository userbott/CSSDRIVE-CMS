<?php

    namespace Cssdrive\Modules\Galleries;

    class Site
    {

        public $core;

        public function __construct($object)
        {
            $this->core = $object;
            $this->_importGalleries();
		}

        private function _importGalleries()
        {
            $assign = []; $tempAssign = [];
            $galleries = $this->core->db('galleries')->toArray();

            if(count($galleries))
            {
                foreach($galleries as $gallery)
                {
                    if($gallery['sort'] == 'ASC')
                        $items = $this->core->db('galleries_items')->where('gallery', $gallery['id'])->asc('id')->toArray();
                    else
                        $items = $this->core->db('galleries_items')->where('gallery', $gallery['id'])->desc('id')->toArray();
                            
                    $tempAssign = $gallery;

                    if(count($items))
                    {
                        foreach($items as &$item)
                        {
                            $item['src'] = unserialize($item['src']);
                        }

                        $tempAssign['items'] = $items;
                        $this->core->tpl->set('gallery', $tempAssign);

                        $assign[$gallery['slug']] = $this->core->tpl->draw(MODULES.'/galleries/view/gallery.html');
                    }
                }
            }
            $this->core->tpl->set('gallery', $assign);

            $this->core->addCSS(url('cssdrive/dist/lightbox/css/lightbox.min.css'));
            $this->core->addJS(url('cssdrive/dist/lightbox/js/lightbox.min.js'));
        }

    }